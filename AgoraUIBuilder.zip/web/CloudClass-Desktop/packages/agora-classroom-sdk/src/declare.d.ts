declare const CLASSROOM_SDK_VERSION: string;
declare const BUILD_TIME: string;
declare const BUILD_COMMIT_ID: string;
declare const EDU_CATEGORY: string;
