export enum ControlState {
  NotAllowedControlled = '0',
}
