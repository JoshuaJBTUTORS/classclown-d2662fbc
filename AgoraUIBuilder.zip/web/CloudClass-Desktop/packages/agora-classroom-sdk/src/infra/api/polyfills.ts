//@ts-ignore
require('matchmedia-polyfill');
require('matchmedia-polyfill/matchMedia.addListener');
