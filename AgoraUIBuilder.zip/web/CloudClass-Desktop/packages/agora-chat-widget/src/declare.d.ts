export function dispatchVisibleUI(config: any): void;
export function dispatchShowChat(config: any): void;
export function dispatchShowMiniIcon(config: any): void;
export function HXChatRoom(props: any): JSX.Element;
