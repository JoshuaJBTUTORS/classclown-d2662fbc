const polling_zh = {
  widget_polling: {
    appName: '投票器',
    start: '开始投票',
    restart: '重新开始',
    over: '结束投票',
    submit: '投票',
    change: '修改投票',
    'input-tip': '请输入投票问题',
    'item-tip': '请输入选项内容',
    'single-sel': '单选',
    'mul-sel': '多选',
  },
};

export default polling_zh;
