const countdown_zh = {
  widget_countdown: {
    appName: '计时器',
    start: '开始',
    seconds: '秒',
    restart: '重新开始',
  },
};

export default countdown_zh;
