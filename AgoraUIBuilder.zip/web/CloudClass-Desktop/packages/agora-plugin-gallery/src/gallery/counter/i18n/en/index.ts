const countdown_en = {
  widget_countdown: {
    appName: 'Countdown',
    start: 'Start',
    seconds: 's',
    restart: 'Restart',
  },
};

export default countdown_en;
