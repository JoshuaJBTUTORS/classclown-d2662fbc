export type StreamMediaPlayerInterface = {
  refresh: () => void;
};
