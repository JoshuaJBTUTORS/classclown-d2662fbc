# `agora-rte-sdk`

> TODO: description

## Usage

```
const agoraRteSdk = require('agora-rte-sdk');

// TODO: DEMONSTRATE API
```
