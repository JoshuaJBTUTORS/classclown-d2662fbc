import '~styles/global.css';
import '~styles/scenario.css';
