import { addons } from '@storybook/addons';
import { theme } from './customize-theme';

addons.setConfig({
  theme: theme,
});
